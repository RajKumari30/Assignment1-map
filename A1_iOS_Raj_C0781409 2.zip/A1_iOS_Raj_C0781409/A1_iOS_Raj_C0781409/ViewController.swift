//
//  ViewController.swift
//  A1_iOS_Raj_C0781409
//
//  Created by user186048 on 1/25/21.
//

import UIKit
import MapKit

class ViewController: UIViewController
{

    
    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
      //define longitude and latitude
        let latitude: CLLocationDegrees = 43.6834
        let longitude: CLLocationDegrees = -79.7663
        //display marker on map
        displayLocation(latitude: latitude, longitude: longitude, title: "Brampton City", subtitile: "You are here")
      //add double tap  func
        addDoubleTap()
        
     
    }
    //Mark: - double tap function
    func addDoubleTap()
    {
        let doubleTap = UITapGestureRecognizer(target:self,action: #selector(dropPin))
        doubleTap.numberOfTapsRequired = 2
        mapView.addGestureRecognizer(doubleTap)
    }

    @objc func dropPin(sender: UITapGestureRecognizer) {
        removePin()
        //add annotation
        let touchPoint = sender.location(in: mapView)
        let coordinate = mapView.convert(touchPoint, toCoordinateFrom: mapView)
        let annotation = MKPointAnnotation()
        annotation.title = "My Destination"
        annotation.coordinate = coordinate
        mapView.addAnnotation(annotation)
        
        
    }
    //remove pin from map
    func removePin() {
        for annotation in mapView.annotations
        {
            mapView.removeAnnotation(annotation)
        }
        //mapView.removeAnnotations(mapView.Annotations)
    }
     
    //display user location
    
    func displayLocation(latitude:CLLocationDegrees,longitude: CLLocationDegrees,title:String,
                         subtitile:String)
    {
       //display span
        let latDelta: CLLocationDegrees = 0.05
        let lngDelta: CLLocationDegrees = 0.05
        let span = MKCoordinateSpan(latitudeDelta: latDelta,longitudeDelta: lngDelta)
        // define location
        let location = CLLocationCoordinate2D(latitude: latitude,longitude: longitude)
        //define region
        let region = MKCoordinateRegion(center: location,span: span)
        //set region
        mapView.setRegion(region,animated: true)
        //define annotation
        let annotation = MKPointAnnotation()
            annotation.title = title
            annotation.subtitle = subtitile
            annotation.coordinate = location
            mapView.addAnnotation(annotation)
    }
}
     
        
        
        


